import base64
import configparser
import datetime
import logging
import os
import sys
import time

from CSV_Loader import CSV_loader
from NotisApi import NotisApi
from TradingSegment import Tradingsegment
from CSV_Operation import CSV_Operations
from ConfigLoader import ConfigLoader

from Logger import _logger

_logger = logging.getLogger('notis')

def is_end_time(cur_time, config):
    return cur_time.tm_hour >= config["end_hour"] and cur_time.tm_min >= config["end_min"]

if __name__ == "__main__":
    csv_op = None
    csvloader = None
    try:
        # Initialize ConfigLoader and load configurations
        config_loader = ConfigLoader()
        common_dict = config_loader.load_common_config()
        csvldr_dict = config_loader.load_csv_loader_config()
        csvloader = CSV_loader(csvldr_dict)
     
        start_hour = common_dict.get("start_hour", 0)  
        start_min = common_dict.get("start_min", 0)
        
        
    except Exception as e:
        _logger.error("Exception occurred during Initial Setup")
        _logger.error(e)
        print(e)
        exit(1)
    
    # Control Loop
    while True:
        
        cur_time = time.localtime()
        if (cur_time.tm_hour >= common_dict["start_hour"] 
                and cur_time.tm_hour < common_dict["end_hour"] 
                and datetime.date.today().isoweekday() not in [6, 7]):
            
            _logger.error(f"---------------------STARTED FOR {datetime.datetime.today().date()}---------------------")
            print(f"---------------------STARTED FOR {datetime.datetime.today().date()}---------------------")
            try:
                Total_trds_loaded = 0
                Total_trds_received = 0
                Total_iterations = 0
                trading_seg_obj_list = []

                try:
                     for segment in common_dict["segments"]:
                        conf = config_loader.load_segment_config(segment)
                        trad_seg = Tradingsegment(segment, common_dict["common_file_name"], conf)
                        csv_op = CSV_Operations()
                        csv_op.empty_csv(f"./csv/{trad_seg.file_name}")
                        trading_seg_obj_list.append(trad_seg)
                except Exception as e:
                    _logger.error("Failed to initialize trading segments")
                    _logger.error(e)
                    print(e)
                    break
                        
                NotisApi.setClassConfig(common_dict)
                
            except Exception as e:
                _logger.error("Exception during file renaming/setup")
                _logger.debug("Exception during file renaming/setup")
                _logger.error(e)
                print(e)

            # Main processing loop
            while True:
                try:
                    cur_time = time.localtime()
                    if is_end_time(cur_time, common_dict):
                        print("Terminating MAIN LOOP at End time -> ")
                        _logger.error("Terminating MAIN LOOP at End time -> ")
                        break

                    Total_iterations += 1
                    _logger.error(f"Iteration No: {Total_iterations}")
                    print(f"Iteration No: {Total_iterations}")
                    
                    for seg_obj in trading_seg_obj_list:                        
                        try:
                            print("Calling start_notis_api")
                            trd_rspns = NotisApi.start_notis_api(seg_obj)

                            if trd_rspns.get('status', 'fail') == 'fail':
                                _logger.error("Login Failed")
                                print("Login Failed")
                                time.sleep(common_dict["sleep_time"])
                                break
                            elif trd_rspns.get('status', 'fail') == 'success':
                                _logger.error(trd_rspns)
                                print(trd_rspns)
                                msg_code = trd_rspns['messages']['code']
                                msg_id = trd_rspns['data']['msgId']
                                _logger.error(f"Response received: msg_code:{msg_code} msg_id:{msg_id}")
                                seg_obj.process_notis_data(trd_rspns['data']['tradesInquiry'])
                                
                                batch_count = seg_obj.batch_count
                                if batch_count == 0:
                                    _logger.error("No new Trades received")
                                    time.sleep(common_dict["sleep_time"])
                                else:
                                    Total_trds_received += batch_count
                                    print(f"Number of trades in batch: {batch_count}")
                                    _logger.error(f"Calling CSV loader for {seg_obj.section} segment")
                                    exit_code = csvloader.load_csv(f"csv/{seg_obj.file_name}") 
                                    success_count = csvloader.get_success_count()

                                    if success_count > 0:
                                        print(f"Success count is {success_count}, emptying CSV...")
                                        csv_op.empty_csv(f"./csv/{seg_obj.file_name}")
                                    else:
                                        print(f"Success count is {success_count}, CSV will not be emptied.")

                                    time.sleep(common_dict["sleep_time"])
                        except Exception as e:
                            _logger.error("Exception in segment processing")
                            _logger.error(e)
                            print(e)

                except Exception as e:
                    _logger.error("Exception in main processing loop")
                    _logger.error(e)
                    print(e)

        else:
            _logger.error("Idle Mode")
            _logger.error(f"Current time: {cur_time.tm_hour}:{cur_time.tm_min}")
            _logger.error(f"Start time: {start_hour}:{start_min}")

            print("Idle Mode")
            print(f"Current time: {cur_time.tm_hour}:{cur_time.tm_min}")
            print(f"Start time: {start_hour}:{start_min}")

            time.sleep(1800)