import datetime
import logging
import os
import sys
import traceback

from Logger import _logger

class Tradingsegment:
    def __init__(self, section, common_file_name, config_dict):
        self._logger = logging.getLogger(config_dict["logger_name"])
        self.section = section
        self.user_ids = config_dict["user_ids"]
        self.user_list = self.user_ids.split(",")
        self.file_name = config_dict["file_name"]
        self.common_file_name = common_file_name
        self.trade_endpoint = config_dict['trade_endpoint']
        self.from_trd_sequence = '0'
        self.first_iteration_flag = True
        self.sequence_no = 1
        _logger.debug("Logger created for segment: %s:" % (self.section))
        self.batch_count = 0
        self.duplicate_csv = config_dict["duplicate_csv"]
        self.all_formated = config_dict["all_formated"]
        self.last_record = ''
        # print("config_dict", config_dict)
        
    # def write_trade_records(self, curr_trd_date, trade_date_list):
    #     count = 0
    #     formated_data = []
    #     duplicate_data = []
    #     unformatedd_trd = trade_date_list
        
    #     try:
    #         # _logger.error("Formatting start: seq_no: %d: from_trd_sequence: %S:" % (self.sequence_no, self.from_trd_sequence))
    #         for record in unformatedd_trd:
    #             if self.section == 'fo':
    #                 rec_dict = {}
    #                 rec_list = record.split(",")
                    
    #                 if rec_list[10] not in self.user_list:
    #                     send_flag = False
    #                 else:
    #                     send_flag = True
                    
    #                 if send_flag:
    #                     rec_dict['fnt_seq_no'] = rec_list[0]
    #                     rec_dict['fnt_mkt'] = rec_list[1]
    #                     rec_dict['fnt_xchng_trd_no'] = rec_list[2][8:]
    #                     rec_dict['fnt_jiffy'] = rec_list[3]
    #                     rec_dict['fnt_tkn'] = rec_list[4]
    #                     rec_dict['fnt_exctd_qty'] = rec_list[5]
    #                     rec_dict['fnt_exctd_rt'] = int(rec_list[6]) / 100
    #                     rec_dict['fnt_trd_flw'] = rec_list[7]
    #                     rec_dict['fnt_ord_ack_numr'] = rec_list[8]
    #                     rec_dict['fnt_brn_cd'] = rec_list[9]
    #                     rec_dict['fnt_usr_id'] = rec_list[10]                    
    #                     rec_dict['fnt_pro_cli'] = rec_list[11]                   
    #                     rec_dict['fnt_clm_mtch_accnt'] = rec_list[12]                 
    #                     rec_dict['fnt_cp_cd'] = rec_list[13]                     
    #                     # rec_dict['remarks'] = rec_list[14]                  
    #                     rec_dict['fnt_act_typ'] = rec_list[15]   
                                        
    #                     if rec_list[16] == '6001':
    #                         rec_dict['fnt_trns_cd'] = '11'
    #                     elif rec_list[16] == '5530':
    #                         rec_dict['fnt_trns_cd'] = '13'
    #                     elif rec_list[16] == '5440' or rec_list[16] == '5560':
    #                         rec_dict['fnt_trns_cd'] = '16'
    #                     else:
    #                         rec_dict['fnt_trns_cd'] = '12'
                        
                                        
    #                     rec_dict['fnt_trd_dt'] = datetime.datetime.fromtimestamp(int(rec_list[17])+ 315513000).strftime("%d %b %Y %H:%M:%S")  
                                          
    #                     if rec_list[18] == '1':
    #                         rec_dict['fnt_booktype'] = 'RL'
    #                     elif rec_list[18] == '3':
    #                         rec_dict['fnt_booktype'] = 'SL'          
    #                     elif rec_list[18] == '7':
    #                         rec_dict['fnt_booktype'] = 'AU'
    #                     else:
    #                         rec_dict['fnt_booktype'] = '--'          
                
    #                     rec_dict['fnt_opp_tm_cd'] = rec_list[19]                  
    #                     rec_dict['fnt_ctcl_id'] = rec_list[20]                   
    #                     rec_dict['fnt_status'] = rec_list[21]                   
    #                     rec_dict['fnt_tm_cd'] = rec_list[22]                     
    #                     rec_dict['fnt_undrlying'] = rec_list[23]                      
    #                     rec_dict['fnt_ser'] = rec_list[24]                      
    #                     rec_dict['fnt_inst'] = rec_list[25]                     
    #                     rec_dict['fnt_expry_dt'] = datetime.datetime.fromtimestamp(int(rec_list[26])+ 315513000).strftime("%d %b %Y %H:%M:%S")                    
    #                     rec_dict['fnt_strk_prc'] =  int(rec_list[27]) / 100                  
    #                     rec_dict['fnt_opt_typ'] = rec_list[28]                  
    #                     rec_dict['fnt_insrt_dt'] = ''              
    #                     rec_dict['fnt_run_indctr'] = ''               

    #                     str_format ="{fnt_seq_no},{fnt_mkt},{fnt_xchng_trd_no},{fnt_jiffy},{fnt_tkn},{fnt_exctd_qty},{fnt_exctd_rt},{fnt_trd_flw},{fnt_ord_ack_numr},{fnt_brn_cd},{fnt_usr_id},{fnt_pro_cli},{fnt_clm_mtch_accnt},{fnt_cp_cd},{fnt_act_typ},{fnt_trns_cd},{fnt_trd_dt},{fnt_booktype},{fnt_opp_tm_cd},{fnt_ctcl_id},{fnt_status},{fnt_tm_cd},{fnt_undrlying},{fnt_ser},{fnt_inst},{fnt_expry_dt},{fnt_strk_prc},{fnt_opt_typ},{fnt_insrt_dt},{fnt_run_indctr}"
    #                     str1 = str_format.format(**rec_dict)
                        
    #                     formated_data.append(str1)
                        
    #                     _logger.error(f"Formatted data count: {len(formated_data)}")
                        
    #                     # _logger.error("Formatted writing start: seq_no: %d: from_trd_sequence: %s:count:%d" % (self.sequence_no))

    #                     # Handling duplicate records and writing data
    #         if len(formated_data) > 0:
    #             last_row = formated_data[-1].split(",")
    #             first_row = formated_data[0].split(",")
    #             if self.first_iteration_flag == True:
    #                 self.last_record = (f"{last_row[0]},{last_row[2]},{last_row[10]},{last_row[21]}")
    #                 _logger.error("fisrt iteration")
    #             else:
    #                 if (self.last_record== f"{first_row[0]},{first_row[2]},{first_row[10]},{first_row[21]}"):
    #                     _logger.error(f"last_record: {self.last_record}")
    #                     _logger.error(f"first_record: {first_row[0]},{first_row[2]},{first_row[10]},{first_row[21]}")
    #                     duplicate_data.append(formated_data[0])
    #                     _logger.error(f"First record skiped: --> {formated_data[0]}")
    #                     formated_data = formated_data[1:]
    #                 self.last_record = (f"{last_row[0]},{last_row[2]},{last_row[10]},{last_row[21]}")
    #             _logger.error("csv open....")
    #             f = open("./csv/" + str(self.file_name), "a")
    #             f_all = open("./csv/" + str(self.all_formated), "a")

    #             for record in formated_data:
    #                 f.write(record + "\n")
    #                 f_all.write(record + "\n")
    #                 count += 1
    #             f.close()
    #             f_all.close()

    #             dis = open("./csv/" + str(self.duplicate_csv), "a")
    #             for record in duplicate_data:
    #                 dis.write(record + "\n")
    #             dis.close()

    #             _logger.error("Formatted writing start:seq_no:%d:from_trd_sequence:%s:count:%d:"% (self.sequence_no, self.from_trd_sequence, count))
    #             print(f"Formated count: {count}")
    #             # print(f"Unformated count: {raw_count}")
    #             return count

    #         else:
    #             _logger.error("No unique records found")
    #             return 0

    #     except Exception as e:
    #         _logger.error("Exception occur: write_trade_records")
    #         _logger.error(e)
    #         _logger.error(traceback.format_exc())
    #         raise (e)

    def write_trade_records(self, curr_trd_date, trade_date_list):
        count = 0
        formated_data = []
        duplicate_data = []
        unformatedd_trd = trade_date_list

        try:
            # Read existing records from all_formated to a set for duplicate checking
            existing_records = set()
            if os.path.exists("./csv/" + str(self.all_formated)):
                with open("./csv/" + str(self.all_formated), "r") as f_all:
                    for line in f_all:
                        rec_fields = line.strip().split(",")
                        key = (rec_fields[0], rec_fields[2], rec_fields[3], rec_fields[8], rec_fields[16], rec_fields[25])
                        existing_records.add(key)

            for record in unformatedd_trd:
                if self.section == 'fo':
                    rec_dict = {}
                    rec_list = record.split(",")

                    # Process the record into dictionary
                    rec_dict['fnt_seq_no'] = rec_list[0]
                    rec_dict['fnt_mkt'] = rec_list[1]
                    rec_dict['fnt_xchng_trd_no'] = rec_list[2][8:]
                    rec_dict['fnt_jiffy'] = rec_list[3]
                    rec_dict['fnt_tkn'] = rec_list[4]
                    rec_dict['fnt_exctd_qty'] = rec_list[5]
                    rec_dict['fnt_exctd_rt'] = int(rec_list[6]) / 100
                    rec_dict['fnt_trd_flw'] = rec_list[7]
                    rec_dict['fnt_ord_ack_numr'] = rec_list[8]
                    rec_dict['fnt_brn_cd'] = rec_list[9]
                    rec_dict['fnt_usr_id'] = rec_list[10]
                    rec_dict['fnt_pro_cli'] = rec_list[11]
                    rec_dict['fnt_clm_mtch_accnt'] = rec_list[12]
                    rec_dict['fnt_cp_cd'] = rec_list[13]
                    rec_dict['fnt_act_typ'] = rec_list[15]   
                                        
                    if rec_list[16] == '6001':
                        rec_dict['fnt_trns_cd'] = '11'
                    elif rec_list[16] == '5530':
                        rec_dict['fnt_trns_cd'] = '13'
                    elif rec_list[16] == '5440' or rec_list[16] == '5560':
                        rec_dict['fnt_trns_cd'] = '16'
                    else:
                        rec_dict['fnt_trns_cd'] = '12'
                    rec_dict['fnt_trd_dt'] = datetime.datetime.fromtimestamp(int(rec_list[17])+ 315513000).strftime("%d %b %Y %H:%M:%S")  
                                          
                    if rec_list[18] == '1':
                        rec_dict['fnt_booktype'] = 'RL'
                    elif rec_list[18] == '3':
                        rec_dict['fnt_booktype'] = 'SL'          
                    elif rec_list[18] == '7':
                        rec_dict['fnt_booktype'] = 'AU'
                    else:
                        rec_dict['fnt_booktype'] = '--'          
            
                    rec_dict['fnt_opp_tm_cd'] = rec_list[19]                  
                    rec_dict['fnt_ctcl_id'] = rec_list[20]                   
                    rec_dict['fnt_status'] = rec_list[21]                   
                    rec_dict['fnt_tm_cd'] = rec_list[22]                     
                    rec_dict['fnt_undrlying'] = rec_list[23]                      
                    rec_dict['fnt_ser'] = rec_list[24]                      
                    rec_dict['fnt_inst'] = rec_list[25]                     
                    rec_dict['fnt_expry_dt'] = datetime.datetime.fromtimestamp(int(rec_list[26])+ 315513000).strftime("%d %b %Y %H:%M:%S")                    
                    rec_dict['fnt_strk_prc'] =  int(rec_list[27]) / 100                  
                    rec_dict['fnt_opt_typ'] = rec_list[28]                  
                    rec_dict['fnt_insrt_dt'] = ''              
                    rec_dict['fnt_run_indctr'] = ''               
                    str_format ="{fnt_seq_no},{fnt_mkt},{fnt_xchng_trd_no},{fnt_jiffy},{fnt_tkn},{fnt_exctd_qty},{fnt_exctd_rt},{fnt_trd_flw},{fnt_ord_ack_numr},{fnt_brn_cd},{fnt_usr_id},{fnt_pro_cli},{fnt_clm_mtch_accnt},{fnt_cp_cd},{fnt_act_typ},{fnt_trns_cd},{fnt_trd_dt},{fnt_booktype},{fnt_opp_tm_cd},{fnt_ctcl_id},{fnt_status},{fnt_tm_cd},{fnt_undrlying},{fnt_ser},{fnt_inst},{fnt_expry_dt},{fnt_strk_prc},{fnt_opt_typ},{fnt_insrt_dt},{fnt_run_indctr}"
                    record = str_format.format(**rec_dict)

                    # Create a key for checking duplicates
                    key = (rec_dict['fnt_seq_no'], rec_dict['fnt_xchng_trd_no'], rec_dict['fnt_jiffy'], 
                           rec_dict['fnt_ord_ack_numr'], rec_dict['fnt_trd_dt'], rec_dict['fnt_expry_dt'])

                    if key in existing_records:
                        # Record is a duplicate
                        duplicate_data.append(record)
                    else:
                        # Add to formatted data and update existing records
                        existing_records.add(key)
                        str_format = "{fnt_seq_no},{fnt_mkt},{fnt_xchng_trd_no},{fnt_jiffy},{fnt_tkn},{fnt_exctd_qty},{fnt_exctd_rt},{fnt_trd_flw},{fnt_ord_ack_numr},{fnt_brn_cd},{fnt_usr_id},{fnt_pro_cli},{fnt_clm_mtch_accnt},{fnt_cp_cd},{fnt_act_typ},{fnt_trns_cd},{fnt_trd_dt},{fnt_expry_dt}"
                        formatted_str = str_format.format(**rec_dict)
                        formated_data.append(formatted_str)

            # Write formatted data to CSV files
            if len(formated_data) > 0:
                with open("./csv/" + str(self.file_name), "a") as f:
                    f.writelines(f"{line}\n" for line in formated_data)
                with open("./csv/" + str(self.all_formated), "a") as f_all:
                    f_all.writelines(f"{line}\n" for line in formated_data)

            # Write discarded data to CSV file
            if len(duplicate_data) > 0:
                with open("./csv/" + str(self.duplicate_csv), "a") as dis:
                    dis.writelines(f"{line}\n" for line in duplicate_data)

            _logger.error(f"Formatted writing start:seq_no:{self.sequence_no}:from_trd_sequence:{self.from_trd_sequence}:count:{len(formated_data)}:")
            return len(formated_data)

        except Exception as e:
            _logger.error("Exception occur: write_trade_records")
            _logger.error(e)
            _logger.error(traceback.format_exc())
            raise e



    def process_notis_data(self, trade_data):
        print("inside process_notis_data")
        cur_from_trd_sequence = self.from_trd_sequence
        self.sequence_no += 1
        trds_inquiry_list = trade_data.split("^")  # converting string to list
        _logger.error("trade_data_header:%s:" % (trds_inquiry_list[0]))
        market_status, curr_trd_date, filler1, filler2, max_seq_no, no_of_recrds = (trds_inquiry_list[0].split(","))
        no_of_recrds = int(no_of_recrds)
        self.response_count = no_of_recrds
        self.from_trade_seq = max_seq_no

        if no_of_recrds == 0:
            self.batch_count = 0
            _logger.error("max_seq:%s:from_trade_seq:%s:" % (max_seq_no, self.from_trd_sequence))
            self.batch_count = 0
        elif no_of_recrds == 1:
            self.batch_count = 0
            _logger.error("max_seq:%s:from_trade_seq:%s:" % (max_seq_no, self.from_trd_sequence))
        # self.from_trd_sequence = trds_inquiry_list[1].split(',')[0]
        else:
            tmp_second_lst_seq_no = trds_inquiry_list[-2].split(",")[0]
            tmp_lst_seq_no = trds_inquiry_list[-1].split(",")[0]
            tmp_no_of_recrds = len(trds_inquiry_list) - 1
            _logger.error("MktStts:%s:Cdate:%s:MaxSeq:%s:noOfRec:%d:tmpMaxSeq:%s:tmpnoOfRec:%d:secondLstSeq:%s:"% (market_status, curr_trd_date, max_seq_no, no_of_recrds, tmp_lst_seq_no, tmp_no_of_recrds, tmp_second_lst_seq_no,))
            if tmp_no_of_recrds == no_of_recrds and tmp_lst_seq_no == max_seq_no:
                try:
                    no_of_records_write = self.write_trade_records(curr_trd_date, trds_inquiry_list[1:])
                    self.first_iteration_flag = False
                    self.batch_count = no_of_records_write
                    _logger.error("no_of_records_write:%d:" % (no_of_records_write))
                    self.from_trd_sequence = tmp_second_lst_seq_no
                    _logger.error("max_seq:%s:from_trade_seq:%s:" % (max_seq_no, self.from_trd_sequence))
                except Exception as e:
                    _logger.error("Exception occur: check_file")
                    print("Exception occur: check_file")
                    _logger.error(e)
                    _logger.error(traceback.format_exc())
                    raise (e)
        _logger.error("prvs sequence :%s: new from_trade_seq:%s:+++++"% (cur_from_trd_sequence, self.from_trd_sequence))
        if int(cur_from_trd_sequence) > int(self.from_trd_sequence):
            _logger.error("Some problem ++++++++++ prvs sequence is greater then new seq:%s:from_trade_seq:%s:"% (cur_from_trd_sequence, self.from_trd_sequence))
            self.from_trd_sequence = cur_from_trd_sequence
