import psycopg2
import traceback
from pathlib import Path
from Logger import _logger

class CSV_loader:
    def __init__(self, sqldict):
        self.username = sqldict['username']
        self.password = sqldict['password']
        self.host = sqldict['host']
        self.port = sqldict['port']
        self.dbname = sqldict['dbname']
        self.table_name = sqldict['table_name']
        self.current_directory = Path(sqldict['current_directory'])
        self.__success_count = 0
        self.__failed_count = 0
        self.conn = None
        self.cursor = None

    def connect_to_postgres(self):
        """Establish a connection to the PostgreSQL database."""
        try:
            self.conn = psycopg2.connect(
                user=self.username,
                password=self.password,
                host=self.host,
                port=self.port,
                dbname=self.dbname
            )
            self.cursor = self.conn.cursor()
            _logger.error("Connected to PostgreSQL Database.")
        except psycopg2.DatabaseError as e:
            _logger.error(f"PostgreSQL Database error: {e}")
            _logger.error(traceback.format_exc())
            raise

    def close_connections(self):
        """Close the database connection and cursor."""
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()
        _logger.error("Database connection closed.")

    def load_csv(self, data_file):
        """Load CSV data into the PostgreSQL table."""
        try:
            self.connect_to_postgres()
            copy_query = f"""
                COPY {self.table_name} FROM STDIN WITH CSV HEADER DELIMITER ','
            """
            print("copy_query :", copy_query)
            with open(data_file, 'r') as f:
                try:
                    self.cursor.copy_expert(sql=copy_query, file=f)
                    self.__success_count = self.cursor.rowcount  # Track the number of successfully loaded rows
                    _logger.error(f"Successfully loaded {self.__success_count} rows from {data_file}.")
                except psycopg2.Error as e:
                    self.__failed_count += 1  # Increment the failure counter
                    _logger.error(f"Error loading data from file {data_file}: {e}")
            self.conn.commit()
        except Exception as e:
            self.conn.rollback()
            _logger.error("Exception occurred while loading data")
            _logger.error(e)
            raise
        finally:
            self.close_connections()

    def get_success_count(self):
        """Return the number of successfully loaded rows."""
        return self.__success_count

    def get_failure_count(self):
        """Return the total number of failed rows."""
        return self.__failed_count
