import configparser
import os
import base64
from Crypto.Cipher import DES3
from Crypto.Util.Padding import unpad
import logging

class ConfigLoader:
    def __init__(self, config_file='notis.conf'):
        self.config_file = config_file
        self.config = configparser.RawConfigParser()
        self.config.read(config_file)
        self.common_dict = {}
        self.csvldr_dict = {}
        self._logger = logging.getLogger('notis_config')

    def load_common_config(self):
        """Loads common configuration settings."""
        try:
            self.common_dict["segments"] = self.config.get("common", "segment").split(",")
            self.common_dict["endpoint"] = self.config.get("common", "endpoint")
            self.common_dict["con_key"] = self.config.get("common", "con_key")
            self.common_dict["con_secret"] = self.config.get("common", "con_secret")
            self.common_dict["login"] = self.config.get("common", "login")
            self.common_dict["member_code"] = self.config.get("common", "member_code")
            self.common_dict["sleep_time"] = float(self.config.get("common", "sleep_time"))
            wait_time = float(self.config.get("common", "wait_time"))
            self.common_dict["access_token"] = str(self.config.get("common", "access_token"))
            # common_dict["http_proxy_url"] = str(config.get("common","http_proxy_url"))
            # common_dict["https_proxy_url"] = str(config.get("common","https_proxy_url"))
            self.common_dict["proxy_flag"] = str(self.config.get("common", "proxy_flag")) 
            self.common_dict["common_file_name"] = self.config.get("common", "common_file_name")
            self.common_dict["start_hour"] = int(self.config.get("common", "start_hour"))
            self.common_dict["end_hour"] = int(self.config.get("common", "end_hour"))
            self.common_dict["end_min"] = int(self.config.get("common", "end_min"))
            # Additional common configurations can be added here as needed
            return self.common_dict
        except Exception as e:
            self._logger.error(f"Error loading common config: {e}")
            raise

    def load_segment_config(self, segment):
        """Loads segment-specific configuration for a given segment."""
        try:
            conf = {}
            for option in self.config.options(segment):
                conf[option] = self.config.get(segment, option)
            return conf
        except Exception as e:
            self._logger.error(f"Error loading segment config for {segment}: {e}")
            raise

    def load_csv_loader_config(self):
        """Loads CSV loader specific configuration."""
        try:    
        # decrypting connection string of database
        # key = b''
        # ciphertext = base64.b64decode(config.get("csvloader", "encryted_connection_string").encode())
        # chipher = DES3.new(key, DES3.MODE_ECB)
        # decrypted_padded_plaintext = chipher.decrypt(ciphertext)
        # decrypted = decrypted_padded_plaintext.rstrip(b" ")
        # decrypted_test = decrypted.decode()
        # con_string_list = decrypted.split(",")
        # for field in con_string_list:
        #     if field.split("=")[0].strip().lower() == "dbname":
        #         csvldr_dict["dbname"] = field.split("=")[1].strip()
        #     elif field.split("=")[0].strip().lower() == "username":
        #         csvldr_dict["username"] = field.split("=")[1].strip()
        #     elif field.split("=")[0].strip().lower() == "password":
        #         csvldr_dict["password"] = field.split("=")[1].strip()
        #     elif field.split("=")[0].strip().lower() == "host":
        #         csvldr_dict["host"] = field.split("=")[1].strip()
        #     elif field.split("=")[0].strip().lower() == "port":
        #         csvldr_dict["port"] = field.split("=")[1].strip()

            self.csvldr_dict["dbname"] = self.config.get("csvloader", "dbname")
            self.csvldr_dict["username"] = self.config.get("csvloader", "username")
            self.csvldr_dict["password"] = self.config.get("csvloader", "password")
            self.csvldr_dict["host"] = self.config.get("csvloader", "host")
            self.csvldr_dict["port"] = self.config.get("csvloader", "port")
            self.csvldr_dict["table_name"] = self.config.get("csvloader", "table_name")
            self.csvldr_dict["current_directory"] = os.getcwd()
            return self.csvldr_dict
        except Exception as e:
            self._logger.error(f"Error loading CSV loader config: {e}")
            raise
