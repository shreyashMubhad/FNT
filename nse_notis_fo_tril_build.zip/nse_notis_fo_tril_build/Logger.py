import logging.config
import os

# Set a default logging level; this can be overridden by a config file or environment variable
default_logging_level = os.getenv('NOTIS_LOG_LEVEL', 'ERROR').upper()

# Default logging configuration
default_logging_config = {
    'version': 1,
    'formatters': {
        'detailed': {
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        },
        'simple': {
            'format': '%(levelname)s - %(message)s',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'level': default_logging_level,
            'formatter': 'detailed',
        },
    },
    'loggers': {
        'notis': {
            'level': default_logging_level,
            'handlers': ['console'],
            'propagate': False,
        },
    },
}

# Configure logging using a file if it exists; otherwise, use default config
logging_config_file_name = 'logging.ini'
if os.path.exists(logging_config_file_name):
    logging.config.fileConfig(logging_config_file_name)
else:
    logging.config.dictConfig(default_logging_config)

# Get the logger
_logger = logging.getLogger('notis')