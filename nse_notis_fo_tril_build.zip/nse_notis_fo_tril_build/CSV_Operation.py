import csv
import os
import traceback
import pandas as pd
from datetime import date
import datetime
from Logger import _logger


class CSV_Operations:

    def empty_csv(self, file):
        headers = [
            "fnt_seq_no",
            "fnt_mkt",
            "fnt_xchng_trd_no",
            "fnt_jiffy",
            "fnt_tkn",
            "fnt_exctd_qty",
            "fnt_exctd_rt",
            "fnt_trd_flw",
            "fnt_ord_ack_numr",
            "fnt_brn_cd",
            "fnt_usr_id",
            "fnt_pro_cli",
            "fnt_clm_mtch_accnt",
            "fnt_cp_cd",
            "fnt_act_typ",
            "fnt_trns_cd",
            "fnt_trd_dt",
            "fnt_booktype",
            "fnt_opp_tm_cd",
            "fnt_ctcl_id",
            "fnt_status",
            "fnt_tm_cd",
            "fnt_undrlying",
            "fnt_ser",
            "fnt_inst",
            "fnt_expry_dt",
            "fnt_strk_prc",
            "fnt_opt_typ",
            "fnt_insrt_dt",
            "fnt_run_indctr"
        ]
        try:
            with open(file, "w", newline="") as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(headers)  # Write the headers to the CSV file
            _logger.error("File " + file[6:-4] + " emptied successfully!")
        except Exception as e:
            _logger.error("Exception occur: empty_csv")
            print("Exception occur: empty_csv")
            _logger.error(traceback.format_exc())
            _logger.error(e)
            raise (e)

    def copy_csv(self, current_file, failed_file):
        try:
            _logger.error(
                "Started copying from "
                + current_file[6:-4]
                + " to "
                + failed_file[6:-4]
            )
            with open(failed_file, "a", newline="") as f_file:
                writer = csv.writer(f_file)
                with open(current_file, "r") as c_file:
                    reader = csv.reader(c_file)
                    for row in reader:
                        writer.writerow(row)
            _logger.error(
                "File: "
                + current_file[6:-4]
                + " copied to "
                + failed_file[6:-4]
                + " successfully!"
            )
        except Exception as e:
            _logger.error("Exception occur: copy_csv")
            print("Exception occur: copy_csv")
            _logger.error(traceback.format_exc())
            _logger.error(e)
            raise (e)

    def get_csv_len(self, file_name):
        try:
            df = pd.read_csv(file_name)
            return len(df) + 1
        except pd.errors.EmptyDataError as e:
            _logger.error(f"{file_name} is Empty!")
            print(f"{file_name} is Empty!")
            return 0
        except Exception as e:
            _logger.error("Exception occur: get_csv_len")
            print("Exception occur: get_csv_len")
            _logger.error(traceback.format_exc())
            _logger.error(e)
            return 0
            raise (e)

    def rename_old_files(self, file_name):
        try:
            if os.path.exists(file_name):
                if datetime.date.today().isoweekday() == 1:
                    yesterday = str(date.fromordinal(date.today().toordinal() - 3))
                else:
                    yesterday = str(date.fromordinal(date.today().toordinal() - 1))
                new_file_name = str(file_name[6:-4] + "_" + yesterday + ".csv")
                if not os.path.exists("./csv/" + new_file_name):
                    os.rename(file_name, "./csv/" + new_file_name)
        except Exception as e:
            _logger.error("Exception: rename_old_files")
            print("Exception: rename_old_files")
            _logger.error(traceback.format_exc())
            _logger.error(e)
            raise (e)
