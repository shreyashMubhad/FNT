import base64
import datetime
import json
import random
import requests
import traceback

from Logger import _logger


class NotisApi:
	endpoint = ''
	con_key = ''
	con_secret = ''
	login = ''
	member_code = ''
	authorization = ''
	sleep_time = ''
	login_data = {'grant_type': 'client_credentials'}
	# proxies = {
	# 	'http': 'http://192.168.115.21:80', #JPR
	# 	'https': 'https://192.168.115.21:80', #JPR
	# }
	# proxies = {
	#	'http': 'http://gateway.zscalertwo.net:443', 
	#	'https': 'https://gateway.zscalertwo.net:443', 
	# }
	proxies = {}
	proxy_flag = False
	is_logged_in = 'N'
	access_token = ''
	expires_in = 0
	
	def __init__(self):
		pass

	@classmethod
	def setClassConfig(cls, comman_conf): # This method configures the class variable using 'comman_conf' dictionary. 
		cls.endpoint = comman_conf['endpoint'] 
		cls.con_key = comman_conf['con_key'] 
		cls.con_secret = comman_conf['con_secret'] 
		cls.login = comman_conf['login'] 
		cls.member_code = comman_conf['member_code'] 
		cls.sleep_time = comman_conf['sleep_time'] 
		auth = cls.con_key + ":" + cls.con_secret
		cls.authorization = base64.b64encode(auth.encode()) 
		if comman_conf["access_token"]!='' :
			cls.access_token=comman_conf["access_token"]
			cls.is_logged_in='Y'
			cls.expires_in = datetime.datetime.now()+datetime.timedelta(seconds=(int(32399)-int(cls.sleep_time)))
		cls.proxies = {
			'http': comman_conf['http_proxy_url'] , 
			'https': comman_conf['https_proxy_url'], 
		}
		if comman_conf['proxy_flag'] in 'yY':
			cls.proxy_flag=True

	@staticmethod
	def get_none_field():# Returns a string containing current timestamp in the specified format.
		return base64.b64encode(str(str(datetime.datetime.now().strftime('%d%m%Y%H%M%S%f')[:-3])+":"+str(random.randint(100000,999999))).encode())

	@classmethod
	def get_login_header(cls): # Returns a dictionary conataining the login headers
		none_value = cls.get_none_field().decode()
		header =  {
			"content-type":"application/x-www-form-urlencoded",
			"Authorization":"Basic " + cls.authorization.decode(),
			"nonce": none_value
                }
		return header
	
	@classmethod
	def notis_login(cls):
		try:
			header = cls.get_login_header()
			_logger.error(f"----Starting login----{cls.endpoint} {cls.login}")
			_logger.error(header)
			response = requests.post(cls.endpoint+cls.login, headers=header,proxies=cls.proxies, data=cls.login_data) 
			_logger.error("Response Status :%d: Reason :%s:" % (response.status_code, response.reason)) 
			_logger.error("Response Text:%s" % response.text)
			_logger.error("----Ended login----")
			repnose = json.loads(response.text) 
	
			if 'expires_in' in repnose:  
				cls.expires_in = datetime.datetime.now()+datetime.timedelta(seconds=(int(repnose['expires_in'])-int(cls.sleep_time)))
				cls.is_logged_in = 'Y'
				cls.access_token = repnose['access_token']
				_logger.error("%s:%s:%s" % (cls.expires_in, cls.is_logged_in, cls.access_token))
				return repnose
			else:
				return repnose
		except Exception as e:
			_logger.error("Exception occur: notis_login")	
			print("Exception occur: notis_login")
			_logger.error(traceback.format_exc())
			_logger.error(e)
			raise(e)
			
	@classmethod
	def get_trade_entry_header(cls):
		none_value = cls.get_none_field().decode()
		header =  {
			"content-type": "application/json",
			"Authorization":"Bearer " + cls.access_token,
			"nonce": none_value
                }	
		return header
		
	@classmethod
	def get_trade_entry(cls, sgmntobj): # Sends post request to API and get a json response containing trade entries in a CSV which is separated by '^'.
		try:
			msgid_date = datetime.date.today().strftime("%Y%m%d")
			seq = str(sgmntobj.sequence_no).zfill(7)
			msgid = cls.member_code + msgid_date + seq
			data = {'msgId': msgid, 'dataFormat': 'CSV:CSV', 'tradesInquiry': sgmntobj.from_trd_sequence+',ALL,,'}
			payload = {"version": "1.0", "data": data}
			jsonPayload = json.dumps(payload)
			headers = cls.get_trade_entry_header()
			sgmntobj._logger.error("++++ Trade entry +++++++")
			sgmntobj._logger.error(headers)
			sgmntobj._logger.error(payload)
			sgmntobj._logger.error(sgmntobj.section + ":from trade sequence:" + sgmntobj.from_trd_sequence)
			sgmntobj._logger.error("++++Trade entry-end +++++++")
			# if cls.proxy_flag == True:
			# 	print("request with proxy")
			# 	response = requests.post(cls.endpoint + sgmntobj.trade_endpoint, headers=headers,proxies=cls.proxies, data=jsonPayload)
			# else:
			# 	print("request with no proxy")
			response = requests.post(cls.endpoint + sgmntobj.trade_endpoint, headers=headers, data=jsonPayload)
			# response = requests.post(cls.endpoint + sgmntobj.trade_endpoint, headers=headers,proxies=cls.proxies, data=jsonPayload)
			sgmntobj._logger.error("++++Trade entry-post +++++++")
			sgmntobj._logger.error("Response Status :%d: Reason :%s:" % (response.status_code, response.reason))
			sgmntobj._logger.error("++++Trade entry-print +++++++")
			sgmntobj._logger.error(response.text)
			sgmntobj._logger.error(response)
			return json.loads(response.text)
		except Exception as e:	
			sgmntobj._logger.error("Exception occur: get_trade_entry")	
			print(f"Exception occur: get_trade_entry: {e}")		
			# sgmntobj._logger.error(response)
			_logger.error(traceback.format_exc())
			sgmntobj._logger.error(e)
			raise(e)

	@classmethod
	def start_notis_api(cls, sgmntobj):
		try:
			print("Inside start_notis_api")
			print(cls.is_logged_in)
			cls.is_logged_in = 'N'
			if cls.is_logged_in == 'Y' and datetime.datetime.now() < cls.expires_in :
				print("Jumping to step 3")
				return cls.get_trade_entry(sgmntobj)
			else:
				print("Going to fetch access token at step 2")
				return_data = cls.notis_login()
				print("------------------------",return_data)
				if 'access_token' in return_data:
					return cls.get_trade_entry(sgmntobj)
				else:
					return {'status': 'fail', 'message': 'Login failed'}
		except Exception as e:	
			_logger.error("Exception occur: get_trade_entry")	
			print(f"Exception occur: get_trade_entry: {e}")
			_logger.error(traceback.format_exc())
			_logger.error(e)
			raise(e)